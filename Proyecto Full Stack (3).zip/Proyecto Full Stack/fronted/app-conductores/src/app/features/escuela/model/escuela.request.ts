export interface EscuelaRequest {

 id?: number;
  nombre: string;
  ruc: string;
  direccion: string;
  estado?: string;
  ubicacionId: number;
}
