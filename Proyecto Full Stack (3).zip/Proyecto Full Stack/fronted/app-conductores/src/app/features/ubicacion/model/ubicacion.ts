export interface Ubicacion {
  id?: number;
  departamento: string;
  provincia: string;
  distrito: string;
  estado?: string;
}
