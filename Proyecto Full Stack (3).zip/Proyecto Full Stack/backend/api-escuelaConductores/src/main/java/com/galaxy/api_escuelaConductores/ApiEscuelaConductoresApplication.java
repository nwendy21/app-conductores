package com.galaxy.api_escuelaConductores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiEscuelaConductoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiEscuelaConductoresApplication.class, args);
	}

}
